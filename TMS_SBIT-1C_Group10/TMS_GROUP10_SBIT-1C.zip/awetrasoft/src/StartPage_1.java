

import java.applet.AppletContext;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.MediaTracker;
import java.awt.PrintJob;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.print.PrinterJob;
import java.io.File;
import java.io.IOException;
import static java.lang.Thread.sleep;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import java.sql.*; 
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Random; 
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JColorChooser;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JTable;
import javax.swing.Timer;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.WindowConstants;
import javax.swing.table.DefaultTableModel;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.design.JRDesignQuery;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sf.jasperreports.view.JasperViewer;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Elipics
 */
public class StartPage_1 extends javax.swing.JFrame {

   
    private Statement stmt; 
    Connection conn; 
    ResultSet rst; 


    BusEntry be; 
       PreparedStatement pst = null; 
    
    
    Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
    public void clock(){
        Thread clock = new Thread()
        {
            public void run()
            {
                try{
                    while(true){
                    Calendar cal = new GregorianCalendar(); 
        int day = cal.get(Calendar.DAY_OF_MONTH); 
        int month = cal.get(Calendar.MONTH); 
        int year = cal.get(Calendar.YEAR); 
        
        int second = cal.get(Calendar.SECOND); 
        int minute = cal.get(Calendar.MINUTE); 
        int hour = cal.get(Calendar.HOUR); 
        clockLabel.setText("Time "+hour+":"+minute+":"+second+" Date "+year+"/"+month+"/"+day);
                    sleep(1000);
                    }
                }catch (InterruptedException e){
                    e.printStackTrace(); 
                }
                
                
            }
        };
        clock.start(); 
        
    }
    private void EnableOrDisable(){
        if (Login_Window.positionCombo.getSelectedItem()== "Superviser"){
           newUser.setEnabled(false);
            btmv.setEnabled(false);
             
        }else if (Login_Window.positionCombo.getSelectedItem()=="Booking Clerk"){
            newUser.setEnabled(false);
            view.setEnabled(false);
            addDriverMenu.setEnabled(false);
            MR.setEnabled(false);
        }
        else if (Login_Window.positionCombo.getSelectedItem()=="Secretary"){
            newUser.setEnabled(false);
            MR.setEnabled(false);
            addDriverMenu.setEnabled(false);
        }
        ButtonGroup group =new ButtonGroup(); 
        group.add(show);
        group.add(hide);
    }
    
    private void showUserRec(){
        
        try{
            conn = CreateDB.getConnection(); 
            String sql = "select * from tbladmins where UserName ='"+Login_Window.userText.getText()+"'"; 
            pst=conn.prepareStatement(sql); 
            rst=pst.executeQuery(); 
            if (rst.next()){
//            byte[]imagedata = rst.getBytes("Image"); 
//            ImageIcon format = new ImageIcon(imagedata); 
//            UserPic.setIcon(format); 
//            name.setText(login.userText.getText()); 
           
              byte[]imagedata = rst.getBytes("Image"); 
              if(rst.getBytes("Image")!=null){
            ImageIcon format = new ImageIcon(imagedata); 
             Image img = format.getImage();
              Image newImage = img.getScaledInstance(UserPic.getWidth(), UserPic.getHeight(),Image.SCALE_SMOOTH);
               ImageIcon pic = new ImageIcon(newImage);
               
                 UserPic.setIcon(pic);
                 name.setText(rst.getString("UserName"));
                  position.setText(rst.getString("Position")); 
              }else{
                  name.setText(rst.getString("UserName"));
                  position.setText(rst.getString("Position")); 
              }
            }
            }
            catch(SQLException e)
            {
           JOptionPane.showMessageDialog(this,e.getMessage()); 
            
            }
    }
    
      public void windowClosing(WindowEvent e) {
    
       
    }
    public StartPage_1() {
        
        initComponents();
        conn=CreateDB.getConnection(); 
        EnableOrDisable();
        clock(); 
        showUserRec();
       
        
            Image icon = Toolkit.getDefaultToolkit().getImage("D:\\awetrasoft\\src\\images\\BusEaseLogo Icon (5).png");
        setIconImage(icon);
        
        
//        Image image = Toolkit.getDefaultToolkit().getImage("LOGO.gif");
//         MediaTracker tracker = new MediaTracker(this);
//        tracker.addImage(image,0);
//        try {
//            tracker.waitForID(0);
//        }
//        catch(Exception e) {
//            System.out.println(e);
//        }        
//
//        setIconImage(image);

    
        


    }
    
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPopupMenu1 = new javax.swing.JPopupMenu();
        jPanel2 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jButton6 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        jButton8 = new javax.swing.JButton();
        jButton9 = new javax.swing.JButton();
        jButton10 = new javax.swing.JButton();
        jPopupMenu2 = new javax.swing.JPopupMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        jMenu1 = new javax.swing.JMenu();
        jMenu2 = new javax.swing.JMenu();
        jPopupMenu3 = new javax.swing.JPopupMenu();
        jMenuItem3 = new javax.swing.JMenuItem();
        HomePanel = new javax.swing.JPanel();
        jPanel11 = new javax.swing.JPanel();
        clockLabel = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        UserPic = new javax.swing.JLabel();
        name = new javax.swing.JLabel();
        position = new javax.swing.JLabel();
        LogoDash = new javax.swing.JLabel();
        HomeWindowTabs = new javax.swing.JTabbedPane();
        startPanel = new javax.swing.JPanel();
        themeBut1 = new javax.swing.JPanel();
        ImageLabel = new javax.swing.JLabel();
        themeBut = new javax.swing.JPanel();
        TablePanel = new javax.swing.JPanel();
        btnPrint = new javax.swing.JButton();
        btnRefresh = new javax.swing.JButton();
        btnUpdate = new javax.swing.JButton();
        btnAddNew = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        table = new javax.swing.JTable();
        menuBar = new javax.swing.JMenuBar();
        file = new javax.swing.JMenu();
        jMenuItem2 = new javax.swing.JMenuItem();
        jMenuItem4 = new javax.swing.JMenuItem();
        jMenu4 = new javax.swing.JMenu();
        newUser = new javax.swing.JMenuItem();
        addDriverMenu = new javax.swing.JMenuItem();
        btmv = new javax.swing.JMenuItem();
        SendEmail = new javax.swing.JMenuItem();
        MR = new javax.swing.JMenuItem();
        view = new javax.swing.JMenu();
        jMenuItem5 = new javax.swing.JMenuItem();
        jMenuItem9 = new javax.swing.JMenuItem();
        jMenuItem10 = new javax.swing.JMenuItem();
        jMenuItem13 = new javax.swing.JMenuItem();
        jMenu6 = new javax.swing.JMenu();
        jMenuItem7 = new javax.swing.JMenuItem();
        jMenuItem8 = new javax.swing.JMenuItem();
        jMenu8 = new javax.swing.JMenu();
        jMenu3 = new javax.swing.JMenu();
        jMenuItem11 = new javax.swing.JMenuItem();
        jMenuItem6 = new javax.swing.JMenuItem();
        jMenuItem12 = new javax.swing.JMenuItem();
        show = new javax.swing.JRadioButtonMenuItem();
        hide = new javax.swing.JRadioButtonMenuItem();
        jMenu5 = new javax.swing.JMenu();
        jSeparator2 = new javax.swing.JPopupMenu.Separator();

        jPanel2.setBackground(new java.awt.Color(252, 252, 252));
        jPanel2.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));

        jPanel3.setBackground(new java.awt.Color(96, 125, 245));

        jButton6.setText("jButton6");
        jButton6.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        jButton7.setText("jButton6");
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });

        jButton8.setText("jButton6");
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });

        jButton9.setText("jButton6");
        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt);
            }
        });

        jButton10.setText("jButton6");
        jButton10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton10ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButton6, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(2, 2, 2)
                .addComponent(jButton7, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(2, 2, 2)
                .addComponent(jButton8, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(2, 2, 2)
                .addComponent(jButton9, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton10, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(14, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap(20, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton6, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton7, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton8, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton9, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton10, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(291, Short.MAX_VALUE))
        );

        jMenuItem1.setText("jMenuItem1");

        jMenu1.setText("jMenu1");

        jMenu2.setText("jMenu2");

        jPopupMenu3.setBackground(new java.awt.Color(51, 0, 204));
        jPopupMenu3.setBorder(javax.swing.BorderFactory.createTitledBorder("Pop Message"));
        jPopupMenu3.setEnabled(false);

        jMenuItem3.setText("jMenuItem3");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Transport Management System");
        setBackground(new java.awt.Color(255, 255, 255));

        jPanel11.setBackground(new java.awt.Color(33, 45, 62));
        jPanel11.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(37, 99, 145), new java.awt.Color(37, 99, 145), null, null));
        jPanel11.setAlignmentX(500.0F);
        jPanel11.setAlignmentY(250.0F);

        clockLabel.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N

        jLabel10.setFont(new java.awt.Font("Verdana", 1, 13)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("Name: ");

        jLabel13.setFont(new java.awt.Font("Verdana", 1, 13)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(255, 255, 255));
        jLabel13.setText("Position: ");

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(""));

        UserPic.setMaximumSize(new java.awt.Dimension(107, 120));
        UserPic.setMinimumSize(new java.awt.Dimension(107, 120));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(UserPic, javax.swing.GroupLayout.DEFAULT_SIZE, 107, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(UserPic, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        name.setFont(new java.awt.Font("Verdana", 0, 13)); // NOI18N
        name.setForeground(new java.awt.Color(255, 255, 255));

        position.setFont(new java.awt.Font("Verdana", 0, 13)); // NOI18N
        position.setForeground(new java.awt.Color(255, 255, 255));

        LogoDash.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/BusEaseLogo Icon Mini.png"))); // NOI18N
        LogoDash.setMaximumSize(new java.awt.Dimension(107, 120));
        LogoDash.setMinimumSize(new java.awt.Dimension(107, 120));

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel11Layout.createSequentialGroup()
                        .addGap(0, 85, Short.MAX_VALUE)
                        .addComponent(clockLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 173, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel11Layout.createSequentialGroup()
                        .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel11Layout.createSequentialGroup()
                                .addComponent(jLabel13)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(position, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel11Layout.createSequentialGroup()
                                .addComponent(jLabel10)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(name, javax.swing.GroupLayout.PREFERRED_SIZE, 159, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel11Layout.createSequentialGroup()
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(LogoDash, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel11Layout.createSequentialGroup()
                        .addGap(27, 27, 27)
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel11Layout.createSequentialGroup()
                        .addGap(51, 51, 51)
                        .addComponent(LogoDash, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(name, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(23, 23, 23)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel13)
                    .addComponent(position, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 290, Short.MAX_VALUE)
                .addComponent(clockLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        HomeWindowTabs.setFont(new java.awt.Font("Verdana", 0, 13)); // NOI18N
        HomeWindowTabs.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                HomeWindowTabsMouseClicked(evt);
            }
        });

        startPanel.setBackground(new java.awt.Color(255, 255, 255));
        startPanel.setEnabled(false);
        startPanel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                startPanelMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                startPanelMouseEntered(evt);
            }
        });
        startPanel.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                startPanelKeyTyped(evt);
            }
        });

        themeBut1.setBackground(new java.awt.Color(0, 255, 255));
        themeBut1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                themeBut1MouseClicked(evt);
            }
        });
        themeBut1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        ImageLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/BannerAdmin.png"))); // NOI18N
        themeBut1.add(ImageLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1010, 500));

        javax.swing.GroupLayout themeButLayout = new javax.swing.GroupLayout(themeBut);
        themeBut.setLayout(themeButLayout);
        themeButLayout.setHorizontalGroup(
            themeButLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        themeButLayout.setVerticalGroup(
            themeButLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 63, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout startPanelLayout = new javax.swing.GroupLayout(startPanel);
        startPanel.setLayout(startPanelLayout);
        startPanelLayout.setHorizontalGroup(
            startPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, startPanelLayout.createSequentialGroup()
                .addGap(0, 1010, Short.MAX_VALUE)
                .addComponent(themeBut, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(startPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(startPanelLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(themeBut1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        startPanelLayout.setVerticalGroup(
            startPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, startPanelLayout.createSequentialGroup()
                .addContainerGap(428, Short.MAX_VALUE)
                .addComponent(themeBut, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
            .addGroup(startPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(startPanelLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(themeBut1, javax.swing.GroupLayout.PREFERRED_SIZE, 503, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        HomeWindowTabs.addTab("Start ", new javax.swing.ImageIcon(getClass().getResource("/images/start.jpg")), startPanel); // NOI18N

        TablePanel.setFont(new java.awt.Font("Georgia", 0, 14)); // NOI18N

        btnPrint.setFont(new java.awt.Font("Verdana", 0, 13)); // NOI18N
        btnPrint.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/print.png"))); // NOI18N
        btnPrint.setText("Print");
        btnPrint.setToolTipText("Make a print of this data.");
        btnPrint.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPrintActionPerformed(evt);
            }
        });

        btnRefresh.setFont(new java.awt.Font("Verdana", 0, 13)); // NOI18N
        btnRefresh.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/refresh.JPG"))); // NOI18N
        btnRefresh.setText("Refresh");
        btnRefresh.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRefreshActionPerformed(evt);
            }
        });

        btnUpdate.setFont(new java.awt.Font("Verdana", 0, 13)); // NOI18N
        btnUpdate.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Update....JPG"))); // NOI18N
        btnUpdate.setText("Update");
        btnUpdate.setToolTipText("Update bus entries using this button.");
        btnUpdate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUpdateActionPerformed(evt);
            }
        });

        btnAddNew.setFont(new java.awt.Font("Verdana", 0, 13)); // NOI18N
        btnAddNew.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/addnew....JPG"))); // NOI18N
        btnAddNew.setText("Add New");
        btnAddNew.setToolTipText("Add new bus entries using this button");
        btnAddNew.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddNewActionPerformed(evt);
            }
        });

        jScrollPane1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        table.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
        table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Bus No.", "Bus No. Plate", "Model", "Capcity", "Date Purchased", "Insurance Status", "Date Insured", "Expiry Date"
            }
        ));
        table.setEnabled(false);
        jScrollPane1.setViewportView(table);

        javax.swing.GroupLayout TablePanelLayout = new javax.swing.GroupLayout(TablePanel);
        TablePanel.setLayout(TablePanelLayout);
        TablePanelLayout.setHorizontalGroup(
            TablePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, TablePanelLayout.createSequentialGroup()
                .addContainerGap(574, Short.MAX_VALUE)
                .addComponent(btnAddNew)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnUpdate)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnRefresh)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnPrint)
                .addGap(18, 18, 18))
            .addGroup(TablePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1)
                .addContainerGap())
        );
        TablePanelLayout.setVerticalGroup(
            TablePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TablePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 39, Short.MAX_VALUE)
                .addGroup(TablePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnPrint)
                    .addComponent(btnRefresh)
                    .addComponent(btnUpdate)
                    .addComponent(btnAddNew)))
        );

        HomeWindowTabs.addTab("Vehicle Infomation", new javax.swing.ImageIcon(getClass().getResource("/images/carinfopic.JPG")), TablePanel); // NOI18N

        javax.swing.GroupLayout HomePanelLayout = new javax.swing.GroupLayout(HomePanel);
        HomePanel.setLayout(HomePanelLayout);
        HomePanelLayout.setHorizontalGroup(
            HomePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(HomePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(HomeWindowTabs)
                .addContainerGap())
        );
        HomePanelLayout.setVerticalGroup(
            HomePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(HomePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(HomePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(HomeWindowTabs, javax.swing.GroupLayout.PREFERRED_SIZE, 541, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        menuBar.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N

        file.setText("File");
        file.setFont(new java.awt.Font("Verdana", 0, 13)); // NOI18N

        jMenuItem2.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F4, java.awt.event.InputEvent.CTRL_MASK));
        jMenuItem2.setFont(new java.awt.Font("Verdana", 0, 13)); // NOI18N
        jMenuItem2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Originals/exit icon.png"))); // NOI18N
        jMenuItem2.setText("Exit");
        jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem2ActionPerformed(evt);
            }
        });
        file.add(jMenuItem2);

        jMenuItem4.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_ESCAPE, 0));
        jMenuItem4.setFont(new java.awt.Font("Verdana", 0, 13)); // NOI18N
        jMenuItem4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Originals/logout icon.png"))); // NOI18N
        jMenuItem4.setText("Logout");
        jMenuItem4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem4ActionPerformed(evt);
            }
        });
        file.add(jMenuItem4);

        menuBar.add(file);

        jMenu4.setText("Operations");
        jMenu4.setFont(new java.awt.Font("Verdana", 0, 13)); // NOI18N

        newUser.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_U, java.awt.event.InputEvent.CTRL_MASK));
        newUser.setFont(new java.awt.Font("Verdana", 0, 13)); // NOI18N
        newUser.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Originals/new user icon.png"))); // NOI18N
        newUser.setText("New User");
        newUser.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                newUserActionPerformed(evt);
            }
        });
        jMenu4.add(newUser);

        addDriverMenu.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_N, java.awt.event.InputEvent.CTRL_MASK));
        addDriverMenu.setFont(new java.awt.Font("Verdana", 0, 13)); // NOI18N
        addDriverMenu.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Originals/new driver icon.png"))); // NOI18N
        addDriverMenu.setText("Add Driver");
        addDriverMenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addDriverMenuActionPerformed(evt);
            }
        });
        jMenu4.add(addDriverMenu);

        btmv.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_M, java.awt.event.InputEvent.CTRL_MASK));
        btmv.setFont(new java.awt.Font("Verdana", 0, 13)); // NOI18N
        btmv.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/book.JPG"))); // NOI18N
        btmv.setText("Travel Movements");
        btmv.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btmvActionPerformed(evt);
            }
        });
        jMenu4.add(btmv);

        SendEmail.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_T, java.awt.event.InputEvent.CTRL_MASK));
        SendEmail.setFont(new java.awt.Font("Verdana", 0, 13)); // NOI18N
        SendEmail.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Originals/email icon.png"))); // NOI18N
        SendEmail.setText("Send Email");
        SendEmail.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SendEmailActionPerformed(evt);
            }
        });
        jMenu4.add(SendEmail);

        MR.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_R, java.awt.event.InputEvent.ALT_MASK | java.awt.event.InputEvent.CTRL_MASK));
        MR.setFont(new java.awt.Font("Verdana", 0, 13)); // NOI18N
        MR.setText("Master Reset");
        MR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MRActionPerformed(evt);
            }
        });
        jMenu4.add(MR);

        menuBar.add(jMenu4);

        view.setText("View");
        view.setFont(new java.awt.Font("Verdana", 0, 13)); // NOI18N

        jMenuItem5.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F2, 0));
        jMenuItem5.setFont(new java.awt.Font("Verdana", 0, 13)); // NOI18N
        jMenuItem5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Originals/driver info icon.png"))); // NOI18N
        jMenuItem5.setText("Driver Details");
        jMenuItem5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem5ActionPerformed(evt);
            }
        });
        view.add(jMenuItem5);

        jMenuItem9.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F3, 0));
        jMenuItem9.setFont(new java.awt.Font("Verdana", 0, 13)); // NOI18N
        jMenuItem9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/movDetails.JPG"))); // NOI18N
        jMenuItem9.setText("Movement Details");
        jMenuItem9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem9ActionPerformed(evt);
            }
        });
        view.add(jMenuItem9);

        jMenuItem10.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F4, 0));
        jMenuItem10.setFont(new java.awt.Font("Verdana", 0, 13)); // NOI18N
        jMenuItem10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Archive icon.png"))); // NOI18N
        jMenuItem10.setText("Archived Movements");
        jMenuItem10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem10ActionPerformed(evt);
            }
        });
        view.add(jMenuItem10);

        jMenuItem13.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F5, 0));
        jMenuItem13.setFont(new java.awt.Font("Verdana", 0, 13)); // NOI18N
        jMenuItem13.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/userend icon.png"))); // NOI18N
        jMenuItem13.setText("User-End Display");
        jMenuItem13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem13ActionPerformed(evt);
            }
        });
        view.add(jMenuItem13);

        menuBar.add(view);

        jMenu6.setText("Tools");
        jMenu6.setFont(new java.awt.Font("Verdana", 0, 13)); // NOI18N

        jMenuItem7.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_C, java.awt.event.InputEvent.ALT_MASK));
        jMenuItem7.setFont(new java.awt.Font("Verdana", 0, 13)); // NOI18N
        jMenuItem7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Originals/calcu icon (1).png"))); // NOI18N
        jMenuItem7.setText("Calculator");
        jMenuItem7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem7ActionPerformed(evt);
            }
        });
        jMenu6.add(jMenuItem7);

        jMenuItem8.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_N, java.awt.event.InputEvent.ALT_MASK));
        jMenuItem8.setFont(new java.awt.Font("Verdana", 0, 13)); // NOI18N
        jMenuItem8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Originals/notepad icon.png"))); // NOI18N
        jMenuItem8.setText("Notepad");
        jMenuItem8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem8ActionPerformed(evt);
            }
        });
        jMenu6.add(jMenuItem8);

        menuBar.add(jMenu6);

        jMenu8.setText("Window");
        jMenu8.setFont(new java.awt.Font("Verdana", 0, 13)); // NOI18N

        jMenu3.setText("Theme");
        jMenu3.setFont(new java.awt.Font("Verdana", 0, 13)); // NOI18N

        jMenuItem11.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F9, 0));
        jMenuItem11.setFont(new java.awt.Font("Verdana", 0, 13)); // NOI18N
        jMenuItem11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/yingtheme.JPG"))); // NOI18N
        jMenuItem11.setText("Color");
        jMenuItem11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem11ActionPerformed(evt);
            }
        });
        jMenu3.add(jMenuItem11);

        jMenuItem6.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F10, 0));
        jMenuItem6.setFont(new java.awt.Font("Verdana", 0, 13)); // NOI18N
        jMenuItem6.setText("Nimbus");
        jMenuItem6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem6ActionPerformed(evt);
            }
        });
        jMenu3.add(jMenuItem6);

        jMenuItem12.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_W, java.awt.event.InputEvent.CTRL_MASK));
        jMenuItem12.setFont(new java.awt.Font("Verdana", 0, 13)); // NOI18N
        jMenuItem12.setText("Windows Theme");
        jMenuItem12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem12ActionPerformed(evt);
            }
        });
        jMenu3.add(jMenuItem12);

        jMenu8.add(jMenu3);

        show.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F5, 0));
        show.setFont(new java.awt.Font("Verdana", 0, 13)); // NOI18N
        show.setSelected(true);
        show.setText("Show");
        show.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                showActionPerformed(evt);
            }
        });
        jMenu8.add(show);

        hide.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F6, 0));
        hide.setFont(new java.awt.Font("Verdana", 0, 13)); // NOI18N
        hide.setSelected(true);
        hide.setText("Hide");
        hide.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                hideActionPerformed(evt);
            }
        });
        jMenu8.add(hide);

        menuBar.add(jMenu8);

        jMenu5.setText("Help");
        jMenu5.setFont(new java.awt.Font("Verdana", 0, 13)); // NOI18N
        jMenu5.add(jSeparator2);

        menuBar.add(jMenu5);

        setJMenuBar(menuBar);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(HomePanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(HomePanel, javax.swing.GroupLayout.PREFERRED_SIZE, 552, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(54, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
  

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton8ActionPerformed

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton9ActionPerformed

    private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton10ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton10ActionPerformed

    private void jMenuItem2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem2ActionPerformed
 String ActCmd = evt.getActionCommand();
                String ObjButtons[] = {"Yes", "No"};
        int PromptResult = JOptionPane.showOptionDialog(null, "Are you sure to exit?",
                "Confirm exit", JOptionPane.DEFAULT_OPTION, JOptionPane.WARNING_MESSAGE, null, ObjButtons, ObjButtons[1]);
           if(PromptResult == JOptionPane.YES_OPTION){
                JOptionPane.showMessageDialog(null, "Thanks for Using");
            }
                
       
     
       
       
       
    }//GEN-LAST:event_jMenuItem2ActionPerformed

    private void btnAddNewActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddNewActionPerformed
        BusEntry Bus_Entry = new BusEntry();
     
        try{   
            Bus_Entry.setLocationRelativeTo(null);
            Bus_Entry.setVisible(true);
        }catch(Exception e){
               
        }
    }//GEN-LAST:event_btnAddNewActionPerformed

    private void btnRefreshActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRefreshActionPerformed
     
        reloaded(); 
      
       
    }//GEN-LAST:event_btnRefreshActionPerformed

    private void startPanelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_startPanelMouseClicked
     count=0; 
    }//GEN-LAST:event_startPanelMouseClicked

    private void HomeWindowTabsMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_HomeWindowTabsMouseClicked
        count=0; 
        reloaded(); 
    }//GEN-LAST:event_HomeWindowTabsMouseClicked

    private void startPanelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_startPanelMouseEntered
        // TODO add your handling code here:
        count=0; 
    }//GEN-LAST:event_startPanelMouseEntered

    private void themeBut1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_themeBut1MouseClicked
          count++;
        if (count==4){
         
            String ObjButtons[] = {"Yes", "No"};
            int PromptResult = JOptionPane.showOptionDialog(null, "Entering chat session?",
                "ATTENTION!", JOptionPane.INFORMATION_MESSAGE, JOptionPane.WARNING_MESSAGE, null, ObjButtons, ObjButtons[1]);
            if (PromptResult == 0) {

                ChatLogin Cl = new ChatLogin(); 
                
                
            } else {

            }

            count=0;
    }//GEN-LAST:event_themeBut1MouseClicked
    }
    private void jMenuItem8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem8ActionPerformed
//        TextEditor notepad = new TextEditor(); 
//        notepad.setSize(600,500);
//        notepad.setVisible(true);
        
             String ActCmd = evt.getActionCommand();
            if (ActCmd.equalsIgnoreCase("notepad")) {
                try {
                    Runtime.getRuntime().exec("notepad.exe");
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, "Error,Cannot start calculator", "Applicaton Error", JOptionPane.ERROR_MESSAGE);
                }
            }
    }//GEN-LAST:event_jMenuItem8ActionPerformed

    private void btnPrintActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPrintActionPerformed
			 try {
    // TODO add your handling code here:

    Class.forName("com.mysql.jdbc.Driver");
    Connection con = (com.mysql.jdbc.Connection) DriverManager.getConnection("jdbc:mysql://localhost/bus_management_system","root","");
    JasperDesign jdesign = JRXmlLoader.load("D:\\awetrasoft\\src\\BusReports.jrxml");
    String query = "select * from businfo";
    JRDesignQuery updateQuery = new JRDesignQuery();
    updateQuery.setText(query);

    JasperReport jreport = JasperCompileManager.compileReport(jdesign);
    JasperPrint  jprint = JasperFillManager.fillReport(jreport, null,con);

    // Create a new JFrame for the report viewer
    JFrame frame = new JFrame();
    frame.setSize(900, 600);
    frame.setLocationRelativeTo(null); // center the frame on the screen
    frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // close only this frame when done

    JasperViewer viewer = new JasperViewer(jprint, false);
    frame.getContentPane().add(viewer.getContentPane()); // add the viewer's content pane to the frame's content pane
    frame.setVisible(true);

} catch (ClassNotFoundException | SQLException | JRException ex) {
    Logger.getLogger(StartPage_1.class.getName()).log(Level.SEVERE, null, ex);
}

    }//GEN-LAST:event_btnPrintActionPerformed

    private void jMenuItem7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem7ActionPerformed
       String ActCmd = evt.getActionCommand();
            if (ActCmd.equalsIgnoreCase("calculator")) {
                try {
                    Runtime.getRuntime().exec("calc.exe");
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, "Error,Cannot start calculator", "Applicaton Error", JOptionPane.ERROR_MESSAGE);
                }
            }
    }//GEN-LAST:event_jMenuItem7ActionPerformed

    private void startPanelKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_startPanelKeyTyped
        // TODO add your handling code here:
         
    }//GEN-LAST:event_startPanelKeyTyped

    private void btnUpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUpdateActionPerformed
        UpdateWindow upwin = new UpdateWindow(); 
        upwin.setSize(621,512); 
        upwin.setLocationRelativeTo(null);
        upwin.setVisible(true); 
        
        
    }//GEN-LAST:event_btnUpdateActionPerformed

    private void btmvActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btmvActionPerformed
        JFrame mv = new Movements(); 
        mv.pack(); 
        mv.setVisible(true);
        mv.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    }//GEN-LAST:event_btmvActionPerformed

    private void addDriverMenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addDriverMenuActionPerformed
        JFrame addDriver = new Add_Driver(); 
        addDriver.pack(); 
        addDriver.setVisible(true); 
        addDriver.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE); 
    }//GEN-LAST:event_addDriverMenuActionPerformed

    private void jMenuItem5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem5ActionPerformed

            
            JFrame DL =new DriverDetails();
            DL.pack(); 
            DL.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            DL.setLocationRelativeTo(null);
            DL.setVisible(true);
            
  
        
    }//GEN-LAST:event_jMenuItem5ActionPerformed

    private void newUserActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_newUserActionPerformed
        JFrame New = new NewUser(); 
        New.pack(); 
        New.setVisible(true); 
        
    }//GEN-LAST:event_newUserActionPerformed

    private void jMenuItem9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem9ActionPerformed
        JFrame DM = new DailyMovementsRecords(); 
        DM.pack(); 
        DM.setVisible(true);
    }//GEN-LAST:event_jMenuItem9ActionPerformed

    private void jMenuItem11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem11ActionPerformed
        Color color = (Color.orange) ; 
             color =JColorChooser.showDialog(null,"Choose a theme color",color);
             if (color==null)
                 color=(Color.orange);
            themeBut1.setBackground(color);
             themeBut.setBackground(color);
             
    }//GEN-LAST:event_jMenuItem11ActionPerformed

    private void hideActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_hideActionPerformed
    HomePanel.hide();
    }//GEN-LAST:event_hideActionPerformed

    private void showActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_showActionPerformed
    HomePanel.show();
    }//GEN-LAST:event_showActionPerformed

    private void jMenuItem6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem6ActionPerformed
       MainClass.UserInterface(); 
    
    }//GEN-LAST:event_jMenuItem6ActionPerformed

    private void jMenuItem12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem12ActionPerformed
        MainClass.UserWindowsInterface(); 
    }//GEN-LAST:event_jMenuItem12ActionPerformed

    private void MRActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MRActionPerformed

                          String ObjButtons[] = {"Yes", "No"};
                    int PromptResult = JOptionPane.showOptionDialog(null, "WARNING! ALL DATA WOULD BE LOST",
                            "Success", JOptionPane.INFORMATION_MESSAGE, JOptionPane.WARNING_MESSAGE, null, ObjButtons, ObjButtons[1]);
                    if (PromptResult == 0) {
                        reset=887;
            try {
                while (rst.next()){
                String sql ="DELETE FROM driver_details";
                stmt.executeUpdate(sql);
                String sql2 ="DELETE FROM businfo";
                stmt.executeUpdate(sql2);
                String sql3 ="DELETE FROM income";
                stmt.executeUpdate(sql3);
                String sql4 ="DELETE FROM tbladmins where UserName !='Awetrasoft'";
                stmt.executeUpdate(sql4);
                String sql5 ="DELETE FROM routes";
                stmt.executeUpdate(sql5);
                String sql6 ="DELETE FROM revenue";
                stmt.executeUpdate(sql6);
                }
            } catch (SQLException ex) {
                Logger.getLogger(StartPage_1.class.getName()).log(Level.SEVERE, null, ex);
            }
                        
                        
                    } else {
                        
                    }

    }//GEN-LAST:event_MRActionPerformed

    private void jMenuItem4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem4ActionPerformed
         String ActCmd = evt.getActionCommand();
        String ObjButtons[] = {"Yes", "No"};
        int PromptResult = JOptionPane.showOptionDialog(null, "Are you sure to Logout?",
                "Confirm Logout", JOptionPane.DEFAULT_OPTION, JOptionPane.WARNING_MESSAGE, null, ObjButtons, ObjButtons[1]);        
       if (ActCmd.equalsIgnoreCase("Logout")) {
            if(PromptResult == JOptionPane.YES_OPTION){
                
           JOptionPane.showMessageDialog(null,"Thanks For Using!");

                    Login_Window frame = new Login_Window();
                    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                    frame.setVisible(true );
                dispose();
            }
       }
    }//GEN-LAST:event_jMenuItem4ActionPerformed

    private void SendEmailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SendEmailActionPerformed
    EmailAdmin frame = new EmailAdmin();
    
    frame.setVisible(true);
    frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE); 
    
    }//GEN-LAST:event_SendEmailActionPerformed

    private void jMenuItem10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem10ActionPerformed
        ArchivedMovements frame = new  ArchivedMovements();
    frame.setLocationRelativeTo(null);
    frame.setVisible(true);
    frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE); 
    }//GEN-LAST:event_jMenuItem10ActionPerformed

    private void jMenuItem13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem13ActionPerformed
         UserInterface frame = new  UserInterface();
    
    frame.setVisible(true);
    frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE); 
    }//GEN-LAST:event_jMenuItem13ActionPerformed

    /**
     * @param args the command line arguments
     */
    


       public void reloaded() {
               try {
//            stmt = ODBC_class.gcetDBConnection().createStatement();
             stmt = CreateDB.getConnection().createStatement();
        } catch (Exception excp) {
            JOptionPane.showMessageDialog(null, "Error on database connection", "Statement error", JOptionPane.ERROR_MESSAGE);
        }//try catch closed

        try {
         String sql = ("SELECT * FROM businfo ORDER BY BusNo");
         int Numrow=0;
        
     
             
            ResultSet result = stmt.executeQuery(sql);
            while (result.next()) {
               
                if (run==1){
                     int key =0;
         DefaultTableModel dtm = (DefaultTableModel) table.getModel();
         key = table.getRowCount()+1;
         dtm.setRowCount(key);  
                  
                }else if (UpdateWindow.deleted==887){
                                int key =0;
         DefaultTableModel dtm = (DefaultTableModel) table.getModel();
         key = table.getRowCount()-1;
         dtm.setRowCount(key); 
         
         UpdateWindow.deleted=0; 
                }
                
         
                
                
                table.setValueAt(result.getString(1).trim(), Numrow, 0);
                table.setValueAt(result.getString(2).trim(), Numrow, 1);
                table.setValueAt(result.getString(3).trim(), Numrow, 2);
                table.setValueAt(result.getString(4).trim(), Numrow, 3);
                table.setValueAt(result.getString(5).trim(), Numrow, 4);
                table.setValueAt(result.getString(6).trim(), Numrow, 5);
                table.setValueAt(result.getString(7).trim(), Numrow, 6);
                table.setValueAt(result.getString(8).trim(), Numrow, 7);
       Numrow++;

            }//while closed
           run =0;
        } catch (SQLException sqlex) {
            JOptionPane.showMessageDialog(null, "Error on retrieving values", "Error", JOptionPane.ERROR_MESSAGE);
        }//try catch closed
    }//reloaded() closed
       
      //ConfirmExit() closed
       
     
    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel HomePanel;
    private javax.swing.JTabbedPane HomeWindowTabs;
    private javax.swing.JLabel ImageLabel;
    private javax.swing.JLabel LogoDash;
    private javax.swing.JMenuItem MR;
    private javax.swing.JMenuItem SendEmail;
    private javax.swing.JPanel TablePanel;
    private javax.swing.JLabel UserPic;
    private javax.swing.JMenuItem addDriverMenu;
    private javax.swing.JMenuItem btmv;
    private javax.swing.JButton btnAddNew;
    private javax.swing.JButton btnPrint;
    private javax.swing.JButton btnRefresh;
    private javax.swing.JButton btnUpdate;
    private javax.swing.JLabel clockLabel;
    private javax.swing.JMenu file;
    private javax.swing.JRadioButtonMenuItem hide;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenu jMenu4;
    private javax.swing.JMenu jMenu5;
    private javax.swing.JMenu jMenu6;
    private javax.swing.JMenu jMenu8;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem10;
    private javax.swing.JMenuItem jMenuItem11;
    private javax.swing.JMenuItem jMenuItem12;
    private javax.swing.JMenuItem jMenuItem13;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JMenuItem jMenuItem3;
    private javax.swing.JMenuItem jMenuItem4;
    private javax.swing.JMenuItem jMenuItem5;
    private javax.swing.JMenuItem jMenuItem6;
    private javax.swing.JMenuItem jMenuItem7;
    private javax.swing.JMenuItem jMenuItem8;
    private javax.swing.JMenuItem jMenuItem9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPopupMenu jPopupMenu1;
    private javax.swing.JPopupMenu jPopupMenu2;
    private javax.swing.JPopupMenu jPopupMenu3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JPopupMenu.Separator jSeparator2;
    private javax.swing.JMenuBar menuBar;
    private javax.swing.JLabel name;
    private javax.swing.JMenuItem newUser;
    private javax.swing.JLabel position;
    private javax.swing.JRadioButtonMenuItem show;
    private javax.swing.JPanel startPanel;
    public static javax.swing.JTable table;
    private javax.swing.JPanel themeBut;
    private javax.swing.JPanel themeBut1;
    private javax.swing.JMenu view;
    // End of variables declaration//GEN-END:variables
    private Random r; 
    int reset;
    private int count =0;
    private int run = 1; 
}
