
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.design.JRDesignQuery;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sf.jasperreports.view.JasperViewer;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Manicar
 */
public class ArchivedMovements extends javax.swing.JFrame {

    /**
     * Creates new form ArchivedMovements
     */
    public ArchivedMovements() {
        initComponents();
        reloaded();
    }
     private Statement stmt; 
public void reloaded() {
               try {
//            stmt = ODBC_class.gcetDBConnection().createStatement();
              stmt = CreateDB.getConnection().createStatement();
        } catch (Exception excp) {
            JOptionPane.showMessageDialog(null, "Error on database connection", "Statement error", JOptionPane.ERROR_MESSAGE);
        }//try catch closed

        try {
         String sql = ("SELECT * FROM movements_archives ORDER BY id");
         int Numrow=0;
        
     
             
            ResultSet result = stmt.executeQuery(sql);
            while (result.next()) {
               
                if (run==1){
                     int key =0;
         DefaultTableModel dtm = (DefaultTableModel) tableRecords.getModel();
         key = tableRecords.getRowCount()+1;
         dtm.setRowCount(key);  
                  
                }else if (UpdateWindow.deleted==887){
                                int key =0;
         DefaultTableModel dtm = (DefaultTableModel) tableRecords.getModel();
         key = tableRecords.getRowCount()-1;
         dtm.setRowCount(key); 
         
         UpdateWindow.deleted=0; 
                }
                
         
                
                
           tableRecords.setValueAt(result.getString(2).trim(), Numrow, 0);
               tableRecords.setValueAt(result.getString(3).trim(), Numrow, 1);
              tableRecords.setValueAt(result.getString(4).trim(), Numrow, 2);
               tableRecords.setValueAt(result.getString(5).trim(), Numrow, 3);
               tableRecords.setValueAt(result.getString(6).trim(), Numrow, 4);
                tableRecords.setValueAt(result.getString(7).trim(), Numrow, 5);
                tableRecords.setValueAt(result.getString(8).trim(), Numrow, 6);
              
       Numrow++;

            }//while closed
           run =0;
        } catch (SQLException sqlex) {
            JOptionPane.showMessageDialog(null, "Error on retrieving values", "Error", JOptionPane.ERROR_MESSAGE);
        }//try catch closed
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane2 = new javax.swing.JScrollPane();
        tableRecords = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jScrollPane2.setFont(new java.awt.Font("Verdana", 0, 13)); // NOI18N
        jScrollPane2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jScrollPane2MouseClicked(evt);
            }
        });

        tableRecords.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Driver Name", "Plate Number", "Departure (From)", "Destination (To)", "Departure Time", "ETA", "Archived Date"
            }
        ));
        tableRecords.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tableRecordsMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tableRecords);

        jLabel2.setFont(new java.awt.Font("Verdana", 1, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(73, 181, 172));
        jLabel2.setText("ARCHIVES");

        jLabel1.setFont(new java.awt.Font("Georgia", 0, 24)); // NOI18N

        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/print.png"))); // NOI18N
        jButton2.setText("Print");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/refresh.JPG"))); // NOI18N
        jButton3.setText("Refresh");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jButton4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/xzit.jpg"))); // NOI18N
        jButton4.setText("Master Delete");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jButton4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jButton3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton2)
                        .addGap(6, 6, 6))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 854, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(layout.createSequentialGroup()
                            .addGap(6, 6, 6)
                            .addComponent(jLabel2))))
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton2)
                    .addComponent(jButton3)
                    .addComponent(jButton4))
                .addContainerGap(38, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(479, 479, 479))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void tableRecordsMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tableRecordsMouseClicked

    }//GEN-LAST:event_tableRecordsMouseClicked

    private void jScrollPane2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jScrollPane2MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jScrollPane2MouseClicked

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        try {
            // TODO add your handling code here:

            Class.forName("com.mysql.jdbc.Driver");
            Connection con = (com.mysql.jdbc.Connection) DriverManager.getConnection("jdbc:mysql://localhost/bus_management_system","root","");
            JasperDesign jdesign = JRXmlLoader.load("D:\\awetrasoft\\src\\Archives.jrxml");
            String query = "select * from movements_archives";
            JRDesignQuery updateQuery = new JRDesignQuery();
            updateQuery.setText(query);
            
            JasperReport jreport = JasperCompileManager.compileReport(jdesign);
            JasperPrint  jprint = JasperFillManager.fillReport(jreport, null,con);
             JFrame frame = new JFrame();
    frame.setSize(900, 600);
    frame.setLocationRelativeTo(null); // center the frame on the screen
    frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // close only this frame when done
             JasperViewer viewer = new JasperViewer(jprint, false);
    frame.getContentPane().add(viewer.getContentPane()); // add the viewer's content pane to the frame's content pane
    frame.setVisible(true);

            
        } catch (ClassNotFoundException | SQLException | JRException ex) {
            Logger.getLogger(StartPage_1.class.getName()).log(Level.SEVERE, null, ex);
        }

    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        reloaded();
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        try {
    Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/bus_management_system", "root", "");
    Statement stmt = conn.createStatement();
    
    String sql = "DELETE FROM movements_archives";
    stmt.executeUpdate(sql);
    
    JOptionPane.showMessageDialog(null, "Deleted Successfully");
    reloaded();
    stmt.close();
    conn.close();
    
} catch (SQLException e) {
    e.printStackTrace();
}
    }//GEN-LAST:event_jButton4ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ArchivedMovements.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ArchivedMovements.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ArchivedMovements.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ArchivedMovements.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ArchivedMovements().setVisible(true);
            }
        });
    }
 private int run = 1; 
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable tableRecords;
    // End of variables declaration//GEN-END:variables
}
